import "./App.css";
import { useState } from "react";
import axios from "axios";

function App() {
  const [feedback, setFeedback] = useState({
    q1: "",
    q2: "",
    q3: "",
    q4: "",
    q5: "",
  });

  const handleChange = (e) => {
    setFeedback({
      ...feedback,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/feedback", feedback);
      alert("Feedback submitted successfully!");
    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
  };

  return (
    <div className="container">
      <h1>Feedback Form</h1>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" name="q1" value={feedback.q1} onChange={handleChange} />

        <label>Department:</label>
        <input type="text" name="q2" value={feedback.q2} onChange={handleChange} />

        <label>Session title:</label>
        <input type="text" name="q3" value={feedback.q3} onChange={handleChange} />

        <label>Feedback:</label>
        <input type="text" name="q4" value={feedback.q4} onChange={handleChange} />

        <label>Suggestions:</label>
        <input type="text" name="q5" value={feedback.q5} onChange={handleChange} />

        <button type="submit">Submit</button>
      </form>
      <p><a href="/getAllData">View all feedback</a></p>
    </div>
  );
}

export default App;
