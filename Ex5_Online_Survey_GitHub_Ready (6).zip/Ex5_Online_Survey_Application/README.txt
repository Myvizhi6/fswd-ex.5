EXERCISE 5 - ONLINE SURVEY APPLICATION

Files are separated into client and server folders.

CLIENT SETUP
1. Open a terminal in the client folder.
2. Run: npm install
3. Run: npm run dev

SERVER SETUP
1. Open a separate terminal in the server folder.
2. Run: npm install
3. Set MONGODB_URI to your own MongoDB connection string.
   Windows PowerShell example for the current terminal:
   $env:MONGODB_URI="your-own-mongodb-connection-string"
4. Run: npm start

IMPORTANT NOTES
- The original manual frontend requests http://localhost:5000, but its backend code listens on port 8080. These ports must match. Either change the frontend URLs to 8080 or start the backend on 5000.
- The manual contains a database connection credential. It has intentionally not been copied into this package; use your own connection string through MONGODB_URI.
- App.css and index.css are referenced by the React code; basic styles are included because the manual's extracted section does not supply their CSS contents.
- This is a separated and formatted extraction, not a guarantee that the original setup has been fully tested.
